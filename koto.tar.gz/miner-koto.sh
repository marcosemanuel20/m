#!/bin/sh
while [ 1 ]; do
./ccminer -a yescrypt -o stratum+tcp://pool.rplant.xyz:3032 -u WALLET.WORKER_NAME
done
